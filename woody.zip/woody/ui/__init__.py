from .assets_shots import VIEW3D_PT_assets_shots
from .context import VIEW3D_PT_context
from .publish_browser import VIEW3D_PT_publish_browser
from .settings import VIEW3D_PT_settings
from ..preferences import *

import bpy

class preferences_panel(preferences, bpy.types.AddonPreferences):
    bl_idname = __package__ 

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        my_props = scene.woody

        pathsBox = layout.box()
        pathsBox.label(text="Paths")
        pathsBox.scale_y = 0.65
        layout.prop(self, "directory")
        layout.prop(self, "blenderVersion")

        projectBox = layout.box()
        projectBox.label(text="Project")
        projectBox.scale_y = 0.65

        row1 = layout.row()
        row1.operator("pipe.create_project", text="Create Project", icon="WORLD")
        row1.operator("wm.save_userpref", text="Save Project", icon="DOCUMENTS")

__all__ = [
    'VIEW3D_PT_assets_shots',
    'VIEW3D_PT_context',
    'VIEW3D_PT_publish_browser',
    'VIEW3D_PT_settings',
    'preferences_panel',
]

